# Saccharide Classifier 
This is a code tutorial for the article research, ***Single molecule identification of saccharides using a boronated Mycobacterium smegmatis porin A nanopore***，a saccharides classification by machine learning. The goal of this project is to provide an example for those interested in getting into the field of data analytics of artificial intelligence nanopore. Programmed using Python 3.8.2 and the following libraries: Scikit-Learn, Pandas, Numpy, Xgboost and Joblib.

# Table of contents
- [Installation](#installation)
- [Training](#training)
- [Evaluation](#evaluation)
- [Prediction](#Prediction)
- [Results](#results)

## Installation
**💡<font size="3">To use this code as a starting point for ML experimentation,download the related repository `requirements.txt` and `dataset` in a zip file**.</font><br />
&emsp;  To install the required dependencies at the computer terminal:

```setup
pip install -r requirements.txt
```
****
## Training
**💡<font size="3">Events of saccharides sensed by boronated MspA nanopore are selected for recognition. 1000 samples are randomly selected from each saccharide previously. We choose the nine saccharides for the demo and `train.py` provided :</font>**
- `labeled_dataset.csv` for types of ***nine*** saccharides contained below: 
```
D-Fructose (Fru), D-Galactose (Gal), D-Mannose (Man), D-Glucose (Glu), L-Sorbose (L-Sor), D-Ribose (Rib), D-Xylose (Xyl), L-Rhamnose (L-Rha) and GalNAc
```
 
- The feature matrix of these saccharides events are extracted from single channel recordings as `labeled_dataset`,including:
```
mean(ΔI/I0), standard deviation (S.D.), skewness(skew), kurtosis(kurt), peak-to-peak value(pk), minimum(min), maximum(max), median(med) and dwell time(time) 
```
- After being loaded, the set of labeled dataset are randomly split into training set (80% of the labeled dataset) and testing set (20%) with the same proportion of each saccharide. And the training set are standardized, then the standardization scaler of training set is uesd to transform the testing set and saved as `scaler`. The standardized training set is then input to train the six models: 
```
KNN / Xgboot / CART / SVM / GBDT / Random Forest
```

***
## Evaluation

**💡<font size="3">To evaluate six models, the validation scores, confusion matrix and classification reporter are provided**.</font><br />
&emsp;  With the 10-fold cross validation accuracy,the Random Forest model is the best performance model selected for subsequent analysis and then fine-tuned with the grid search. Then the tuned model are finally saved for predicting the unlabeled data:
- During each model evaluating, the confusion matrix and classification reporter (precision, accuracy and recall) for test set are caculated in `train.py` and `model_evaluation.py`.Fine-tuned Random Forest model for example:
```python
#Random Forest model building
rf = RandomForestClassifier(n_estimators=427, max_depth=16, random_state=42)
#model training
clf_RandomF .fit(X_train, Y_train)
#recall\F1\precision\Confusion matrix of test set
prediction_RandomF,scores_RandomF, reporter_RandomF,data_matrix_RandomF = model_evaluation.repoter_classification(clf_RandomF, X_train, Y_train, X_test, Y_test,label_class=label_class)
```
- For each model, the 10-fold cross validation accuracy is caculated. Fine-tuned Random Forest model for example:<br /> 
```python
# 10-fold cross-validation scored by 'accuracy' and 'f1_macro'
cv_scores_RandomF = cross_val_score(clf_RandomF, X_train, Y_train, cv=10, scoring='accuracy').mean()  
```
- Save the pretrained fine-tuned Random Forest model as `rf.pkl`for prediction:
```python
#save model
import joblib
joblib.dump(rf, 'rf.pkl')
```

***
## Prediction

**💡<font size="3">You can download `scaler` to standardize unlabeled data and the best performance pretrained  model `rf.pkl` to predict the standardized unlabeled data--`data_predict` in `predict.py`</font> :**
```python
import joblib
rf = joblib.load('rf.pkl')
#"data_predict" is calculated by using labeled dataset standardization scales to standardize unlabeled dataset  
rf.predict(data_predict)
```
***
## Results
The performances our model achieved are exhibited on the paper ***Single molecule identification of saccharides using a boronated Mycobacterium smegmatis porin A nanopore***.


