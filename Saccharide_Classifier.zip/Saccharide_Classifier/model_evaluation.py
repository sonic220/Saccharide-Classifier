from sklearn.metrics import classification_report, confusion_matrix
import pandas as pd
import numpy as np
def repoter_classification(clf,X_train,Y_train,X_test,Y_test,label_class):
    '''
    args:classfication model, train data features, train data labels, test data features, test data labels, label_list
    return:the preformance of the model
    '''
    clf.fit(X_train, Y_train)
    prediction = clf.predict(X_test)
    data_matrix = pd.DataFrame(confusion_matrix(Y_test, prediction,labels=label_class)) # Confusion matrix
    data_matrix.columns=label_class
    data_matrix.index = label_class
    Data_Matrix = (data_matrix.T / np.sum(data_matrix, 1)).T
    return Data_Matrix