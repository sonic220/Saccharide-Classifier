import joblib
from pandas import read_csv
from sklearn.ensemble import RandomForestClassifier,  GradientBoostingClassifier
import sklearn
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
import warnings
from sklearn.tree import DecisionTreeClassifier
import model_evaluation

#input labeled data set
Labeled_Data = read_csv('labeled_data.csv')
Labeled_Data = Labeled_Data.drop(labels='index', axis=1, index=None, columns=None, inplace=False)
label_class = ["fru", "gal", "man", "glc", "sor", "rib", "xyl", "rha", "GalNAc"]
label = Labeled_Data.iloc[:, -1]
labeled_set = Labeled_Data.iloc[:, :9]

#split training set (80%) and testing set (20%) from labeled data
X_train, X_test, Y_train, Y_test = train_test_split(labeled_set, label, test_size=0.2, random_state=1, stratify=label)
#standardize the data in training set and the standardization scaler of training set is uesd to transform the testing set
stdScale = StandardScaler().fit(X_train)
X_train = stdScale.transform(X_train)
X_test = stdScale.transform(X_test)
#save the standardization scaler
joblib.dump(stdScale, 'scaler')
#################################################################################
#################################################################################
##KNN
clf_knn =KNeighborsClassifier()
#model training
clf_knn.fit(X_train,Y_train)
# 10-fold cross-validation scored of training set
cv_scores_knn = cross_val_score(clf_knn, X_train, Y_train, cv=10, scoring='accuracy').mean()
#confusion matrix of testing set
data_matrix_knn = model_evaluation.repoter_classification(clf_knn, X_train, Y_train, X_test, Y_test, label_class=label_class)
print("KNN 10-fold cross validation accuracy:{}".format(cv_scores_knn))
print("KNN confusion matrix :{}".format(data_matrix_knn))

##Xgboost
#%pip install xgboost
from xgboost.sklearn import XGBClassifier
clf_xgbc = XGBClassifier(random_state=42, verbosity=0)
clf_xgbc.fit(X_train,Y_train)
cv_scores_xgbc = cross_val_score(clf_xgbc, X_train, Y_train, cv=10, scoring='accuracy').mean()   # 10-fold cross-validation
data_matrix_xgbc = model_evaluation.repoter_classification(clf_xgbc, X_train, Y_train, X_test, Y_test, label_class=label_class)
print("Xgboost 10-fold cross validation accuracy:{}".format(cv_scores_xgbc))
print("Xgboost confusion matrix :{}".format(data_matrix_xgbc))

##CART
clf_DeciTree = DecisionTreeClassifier(random_state=42)
clf_DeciTree .fit(X_train, Y_train)
cv_scores_DeciTree = cross_val_score(clf_DeciTree, X_train, Y_train, cv=10, scoring='accuracy').mean()  # 10-fold cross-validation
data_matrix_DeciTree = model_evaluation.repoter_classification(clf_DeciTree, X_train, Y_train, X_test, Y_test, label_class=label_class)
print("CART 10-fold cross validation accuracy:{}".format(cv_scores_DeciTree))
print("CART confusion matrix :{}".format(data_matrix_DeciTree))

##SVM
clf_svm = sklearn.svm.SVC()
clf_svm .fit(X_train, Y_train)
cv_scores_svm = cross_val_score(clf_svm, X_train, Y_train, cv=10, scoring='accuracy').mean()  # 10-fold cross-validation
data_matrix_svm = model_evaluation.repoter_classification(clf_svm, X_train, Y_train, X_test, Y_test, label_class=label_class)
print("SVM 10-fold cross validation accuracy:{}".format(cv_scores_svm))
print("SVM confusion matrix :{}".format(data_matrix_svm))

##GBDT
clf_gbdt = GradientBoostingClassifier(random_state=42)
clf_gbdt.fit(X_train, Y_train)
cv_scores_gbdt = cross_val_score(clf_gbdt, X_train, Y_train, cv=10, scoring='accuracy').mean()  # 10-fold cross-validation
data_matrix_gbdt = model_evaluation.repoter_classification(clf_gbdt, X_train, Y_train, X_test, Y_test, label_class=label_class)
print("GBDT 10-fold cross validation accuracy:{}".format(cv_scores_gbdt))
print("GBDT confusion matrix :{}".format(data_matrix_gbdt))

##Randomforest
RandomForest = RandomForestClassifier(random_state=42)
RandomForest .fit(X_train, Y_train)
pre_test = RandomForest.predict(X_test)
cv_scores_RandomForest = cross_val_score(RandomForest, X_train, Y_train, cv=10, scoring='accuracy').mean()  # 10-fold cross-validation
data_matrix_RandomForest = model_evaluation.repoter_classification(RandomForest, X_train, Y_train, X_test, Y_test, label_class=label_class)
print("Random Forest 10-fold cross validation accuracy:{}".format(cv_scores_RandomForest))
print("Random Forest confusion matrix :{}".format(data_matrix_RandomForest))

##fine-tuned Randomforest
rf = RandomForestClassifier(n_estimators=427, max_depth=16, random_state=42)
rf .fit(X_train, Y_train)
pre_test = rf.predict(X_test)
cv_scores_rf = cross_val_score(rf, X_train, Y_train, cv=10, scoring='accuracy').mean()  # 10-fold cross-validation
data_matrix_rf = model_evaluation.repoter_classification(rf, X_train, Y_train, X_test, Y_test, label_class=label_class)
print("fine-tuned Random Forest 10-fold cross validation accuracy:{}".format(cv_scores_rf))
print("fine-tuned Random Forest confusion matrix :{}".format(data_matrix_rf))

#################################################################################
#save model
joblib.dump(rf, 'rf.pkl')


