import joblib
from pandas import read_csv
#import the standardization scaler of training set 
stdScale = joblib.load('scaler')
#input  unlabeled data set
Unlabeled_Data = read_csv('unlabeled_data.csv')
unlabeled_set = Unlabeled_Data.drop(labels='index', axis=1, index=None, columns=None, inplace=False)
#Standardization
data_predict = stdScale.transform(unlabeled_set)
#load model
rf = joblib.load('rf.pkl')
#predict unlabeled data
predict_label = rf.predict(data_predict)
df = unlabeled_set
df['predict_label'] = predict_label
#save predict_results into .csv file
df.to_csv('unlabeled_predict_results.csv')